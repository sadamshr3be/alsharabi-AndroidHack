<?php


session_start();
// error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/png" href="asset/img/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="asset/css/style.css">
    <link rel="stylesheet" href="asset/css/bootstrap.min.css">


    <link rel="stylesheet" href="asset/css/vanillatoasts.css">


    <link rel="stylesheet" href="asset/css/all.min.css">
    <!-- JavaScript -->
    <script src="asset/js/app/jquery.min.js"></script>
    <script src="asset/js/app/alertify.min.js"></script>
    <link rel="stylesheet" href="asset/css/image.zoom.css">
    <script src="asset/js/app/bootstrap.bundle.min.js"></script>
    <script src="asset/js/app/vanillatoasts.js"></script>


    <!-- CSS -->
    <link rel="stylesheet" href="asset/css/alertify.min.css" />
    <!-- Default theme -->
    <link rel="stylesheet" href="asset/css/alertify-default.min.css" />

    <!-- Bootstrap theme -->
    <link rel="stylesheet" href="asset/css/alertify.bootstrap.min.css" />

    <title>ADB WEBKIT</title>
</head>

<body>
    <!-- Demo header-->
    <section class="py-5 header">
        <div class="container py-4">
            <header class="text-center mb-5 pb-5 text-white">
                <b class="display-4" style="color: green;
font-weight: bold">ADB <b style="color:crimson">WEBKIT</b>
                </b>

                </p>
            </header>