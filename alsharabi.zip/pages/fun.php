<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-fun" role="tabpanel"
    aria-labelledby="v-pills-fun-tab">
    <h4 class="font-italic mb-4 text-center">Fun</h4>
    <hr>
    <button type="button" class="btn btn-primary btn-lg but" id="sendmessage">SendMessage</button>
    <button type="button" class="btn btn-primary btn-lg but" id="openlink">OpenLink</button>
    <button type="button" class="btn btn-primary btn-lg but" id="call">Call</button>
    <button type="button" class="btn btn-primary btn-lg but" id="playmusic">Play Music
        Taggle</button>


</div>