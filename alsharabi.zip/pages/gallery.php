<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-gallery" role="tabpanel"
    aria-labelledby="v-pills-gallery-tab">
    <h4 class="font-italic mb-4 text-center">Gallery</h4>
    <hr>
    <div class="form-group">
        <label for="sel1">Select list:</label>
        <select class="form-control" id="selectgal">
            <option selected>-------------</option>
            <option value="download/png/">png</option>
            <option value="download/jpeg/">jpeg</option>
            <option value="download/gif/">gif</option>
            <option value="download/jpg/">jpg</option>
            <option value="download/mp4/">mp4</option>
            <option value="download/wav/">wav</option>
            <option value="download/mkv/">mkv</option>
            <option value="download/mp3/">mp3</option>
            <option value="download/m4a/">m4a</option>
            <option value="download/ogg/">ogg</option>
            <option value="download/avi/">avi</option>
            <option value="download/apk/">apk</option>
            <option value="download/pdf/">pdf</option>
            <option value="download/txt/">txt</option>
            <option value="download/xml/">xml</option>
            <option value="download/rc/">rc</option>
            <option value="download/sh/">sh</option>
            <option value="download/py/">py</option>
            <option value="download/php/">php</option>
            <option value="download/c/">c</option>
            <option value="download/cpp/">cpp</option>
            <option value="download/bin/">bin</option>
            <option value="download/prop/">prop</option>
            <option value="download/zip/">zip</option>
            <option value="download/rar/">rar</option>
            <option value="download/log/">log</option>
            <option value="download/conf/">conf</option>
            <option value="download/html/">html</option>
            <option value="download/txt/">txt</option>
            <option value="download/so/">so</option>
            <option value="download/ps1/">ps1</option>
            <option value="download/exe/">exe</option>
            <option value="download/other/">other</option>
            <option value="download/folder/">folder</option>
            <option value="download/newfile/">newfile</option>
            <option value="videorecorder/">videorecorder</option>
            <option value="screenshot/">screenshot</option>
            <option value="fileupload/">fileupload</option>
            <div class=" container">


        </select>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="main-box clearfix">
                <div class="table-responsive">
                    <br>

                    <table class="table user-list " id="boxfile">


                    </table>

                </div>

            </div>
        </div>
    </div>
</div>
</div>