<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../asset/img/favicon.png" />

    <script src="../asset/js/app/jquery.min.js"></script>

    <title>Get Position</title>
</head>

<body>
    <div style="width:300px;">
        <div><img src="" /></div>

    </div>
   <script src="../asset/js/project/getops.js"></script type="text/javascript">
</body>

</html>
