<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-payload" role="tabpanel"
    aria-labelledby="v-pills-payload-tab">
    <h4 class="font-italic mb-4 text-center">Payload</h4>
    <hr>
    <div class="form-group purple-border">
        <textarea class="form-control " id="payload-input" rows="3" style="resize: none;"></textarea><br>
        <textarea class="form-control  " readonly id="payload-output" rows="3" style="resize: none;"></textarea><br>
        <br>
        <button type="button" class="btn btn-primary btn-lg but" style="width:100%"
            id="payload-convert">Convert</button>
        <button type="button" class="btn btn-primary btn-lg but" id='payload-copy'>Copy</button>
        <button type="button" class="btn btn-primary btn-lg but" id='payload-execute'>Execute</button>
        <button type="button" class="btn btn-primary btn-lg but" id='payload-save'>Save</button>
        <button type="button" class="btn btn-primary btn-lg but" id='payload-help' style="width:100%">Help</button>






    </div>
</div>