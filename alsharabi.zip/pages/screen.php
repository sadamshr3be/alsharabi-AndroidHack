<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-screen" role="tabpanel"
    aria-labelledby="v-pills-screen-tab">
    <h4 class="font-italic mb-4 text-center">Screen</h4>
    <hr>
    <button type="button" class="btn btn-primary btn-lg but" id="screenshot">ScreenShot</button>
    <button type="button" class="btn btn-primary btn-lg but" id="recoredscreen">RecoredScreen</button>
    <button type="button" class="btn btn-primary btn-lg but" id="setposimg" style="width:100%">GetPosition</button>
    <img src="" class="img-fluid" data-action="zoom" id="screenshot-out">
    <img src="asset/img/1.gif" class="img-fluid" style="display:none" id="loading-screen">
    <video controls id="recoredscreen-out" autoplay class="embed-responsive-item">
        <source src="" type="video/mp4">
    </video>
</div>
