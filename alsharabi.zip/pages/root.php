<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-root" role="tabpanel"
    aria-labelledby="v-pills-root-tab">
    <h4 class="font-italic mb-4 text-center">Root</h4>
    <hr>

</div>