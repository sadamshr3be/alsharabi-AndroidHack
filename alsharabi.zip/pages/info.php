<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-info" role="tabpanel"
    aria-labelledby="v-pills-info-tab">
    <h4 class="font-italic mb-4 text-center">Info</h4>
    <hr>
    <img src="asset/img/android-os.png" clss="img-fluid " id="infoi">
    <div id="box">
        <img src="asset/img/1.gif" class="img-fluid">
    </div>
    <a href="#" class='text-primary' id="list-info" style="display:none">ShowAll</a>

</div>