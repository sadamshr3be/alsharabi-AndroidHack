<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-network" role="tabpanel"
    aria-labelledby="v-pills-network-tab">
    <h4 class="font-italic mb-4 text-center">Network</h4>
    <hr>
    <button type="button" class="btn btn-primary btn-lg but" id="netstat">Netstat</button>
    <button type=" button" class="btn btn-primary btn-lg but" id="ifconfig">ifconfig</button>
    <button type="button" class="btn btn-primary btn-lg but" id="ipaddr">IP</button>
    <button type="button" class="btn btn-primary btn-lg but" id="dumpwifi">DumpWifi</button>
    <textarea class="form-control " readonly id="result-network" rows="3" style="resize: none;"></textarea>
    <img src="asset/img/1.gif" class="img-fluid" id="result-network-loading">

</div>