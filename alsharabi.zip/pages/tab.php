<script>
    document.firstElementChild.style.zoom = 0.85;
</script>
<div class="row">
    <div class="col-md-3">
        <!-- Tabs nav -->
        <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist"
            aria-orientation="vertical">
            <a class="nav-link mb-3 p-3 shadow active " id="v-pills-shell-tab" data-toggle="pill" href="#v-pills-shell"
                role="tab" aria-controls="v-pills-shell" aria-selected="true" onclick="rmkey()"> <i class=" fa fa-greater-than
                mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Shell</span></a>

            <a class="nav-link mb-3 p-3 shadow " id="v-pills-application-application" data-toggle="pill"
                href="#v-pills-application" role="tab" aria-controls="v-pills-application" aria-selected="false">
                <i class="fa fa-box mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Application</span></a>

            <a class="nav-link mb-3 p-3 shadow " id="v-pills-screen-tab" data-toggle="pill" href="#v-pills-screen"
                role="tab" aria-controls="v-pills-screen" aria-selected="false">
                <i class="fa fa-desktop mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Screen</span></a>

            <a class="nav-link mb-3 p-3 shadow " id="v-pills-phone-tab" data-toggle="pill" href="#v-pills-phone"
                role="tab" aria-controls="v-pills-phone" aria-selected="false">
                <i class="fa fa-mobile mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Phone</span></a>

            <a class="nav-link mb-3 p-3 shadow " id="v-pills-files-tab" data-toggle="pill" href="#v-pills-files"
                role="tab" aria-controls="v-pills-files" aria-selected="false">
                <i class="fa    fa-folder-open"></i>
                <span class="font-weight-bold small text-uppercase">Files</span></a>


            <a class="nav-link mb-3 p-3 shadow " id="v-pills-network-tab" data-toggle="pill" href="#v-pills-network"
                role="tab" aria-controls="v-pills-network" aria-selected="false">
                <i class="fa fa-network-wired mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Network</span></a>


            <a class="nav-link mb-3 p-3 shadow " id="v-pills-fun-tab" data-toggle="pill" href="#v-pills-fun" role="tab"
                aria-controls="v-pills-fun" aria-selected="false">
                <i class="fa fa-smile-wink mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Fun</span></a>


            <a class="nav-link mb-3 p-3 shadow" id="v-pills-keyboard-tab" data-toggle="pill" href="#v-pills-keyboard"
                role="tab" aria-controls="v-pills-keyboard" aria-selected="false">
                <i class="fa fa-keyboard mr-2"></i>
                <span class="font-weight-bold small text-uppercase">KeyBoard</span></a>


            <a class="nav-link mb-3 p-3 shadow " id="v-pills-payload-tab" data-toggle="pill" href="#v-pills-payload"
                role="tab" aria-controls="v-pills-payload" aria-selected="false">
                <i class="fa fa-play mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Payload</span></a>

            <a class="nav-link mb-3 p-3 shadow " id="v-pills-root-tab" data-toggle="pill" href="#v-pills-root"
                role="tab" aria-controls="v-pills-root" aria-selected="false">
                <i class="fa fa-bomb mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Root</span></a>
            <a class="nav-link mb-3 p-3 shadow " id="v-pills-info-tab" data-toggle="pill" href="#v-pills-info"
                role="tab" aria-controls="v-pills-info" aria-selected="false">
                <i class="fa fa-info-circle mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Info</span></a>




            <a class="nav-link mb-3 p-3 shadow " id="v-pills-gallery-tab" data-toggle="pill" href="#v-pills-gallery"
                role="tab" aria-controls="v-pills-gallery" aria-selected="false">
                <i class="fa fa-image mr-2"></i>
                <span class="font-weight-bold small text-uppercase">Gallery</span></a>

        </div>
    </div>
