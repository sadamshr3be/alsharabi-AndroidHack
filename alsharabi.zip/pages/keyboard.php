<div class="tab-pane fade shadow rounded bg-white p-5" id="v-pills-keyboard" role="tabpanel"
    aria-labelledby="v-pills-keyboard-tab">
    <h4 class="font-italic mb-4 text-center">KeyBoard</h4>
    <hr>
    <textarea class="form-control " readonly id="result-keyboard" rows="3" style="resize: none;"></textarea><br>

</div>