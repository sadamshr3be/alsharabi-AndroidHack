<?php

require_once "pages/header.php"; 
require_once "pages/tab.php"; 
require_once "pages/shell.php"; 
require_once "pages/application.php"; 
require_once "pages/screen.php";
require_once "pages/files.php";
require_once "pages/phone.php";
require_once "pages/network.php"; 
require_once "pages/fun.php";
require_once "pages/keyboard.php"; 
require_once "pages/payload.php"; 
require_once "pages/root.php"; 
require_once "pages/info.php"; 
require_once "pages/gallery.php";
require_once "pages/alertify.php";   
require_once "pages/jslink.php";

 
?>